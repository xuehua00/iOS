//
//  XHSectorView.h
//  扇形滑动
//
//  Created by 逸族 on 2017/5/10.
//  Copyright © 2017年 yizu. All rights reserved.
//



// 宽度和高度
#define XH_WIDTH [[UIScreen mainScreen] bounds].size.width
#define XH_HEIGHT [[UIScreen mainScreen] bounds].size.height



#import <UIKit/UIKit.h>

@class XHSectorView;

@protocol XHSectorViewDelegate <NSObject>

// 滑动结束,居中的子视图对应数组中的位置，Model数据
- (void)slideEndWithIndex:(NSInteger)index;

@end


@interface XHSectorView : UIView


@property (nonatomic, weak) id<XHSectorViewDelegate> delegate;



/**
 设置外圆大小，环形间距，子视图的个数，子视图显示的数量
 
 @param radius 外圆半径
 @param spacing 环形间距
 @param showCount 子视图显示的个数
 */
- (void)setAbroadViewRadius:(CGFloat)radius andSpacing:(CGFloat)spacing showViewCount:(NSInteger)showCount; // subViewArray:(NSArray *)viewArray


/**
 增加数据(子视图View)
 
 @param viewArray 增加子视图数组
 */
- (void)addSubViewWithSubViewArray:(NSArray *)viewArray;


/**
 下一个
 */
- (void)nextToRigth;


/**
 上一个
 */
- (void)nextToLeft;




/**
 清除AbroadView所有子控件
 */
- (void)clearAllAbroadViewSub;













@end
