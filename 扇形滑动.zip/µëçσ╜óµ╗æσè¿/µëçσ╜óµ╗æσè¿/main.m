//
//  main.m
//  扇形滑动
//
//  Created by 逸族 on 2017/5/5.
//  Copyright © 2017年 yizu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
