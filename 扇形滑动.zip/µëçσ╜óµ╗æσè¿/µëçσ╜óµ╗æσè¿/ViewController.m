//
//  ViewController.m
//  扇形滑动
//
//  Created by 逸族 on 2017/5/5.
//  Copyright © 2017年 yizu. All rights reserved.
//

#import "ViewController.h"
#import "UIView+YZ.h"
#import "XHSectorView.h"

@interface ViewController () <XHSectorViewDelegate>


@property (nonatomic, weak) XHSectorView *sectorView;

@property (nonatomic, weak) UIView *backView;
@property (nonatomic, weak) UILabel *contentLabel;
@property (nonatomic, weak) UIButton *leftButton;           // 上一个
@property (nonatomic, weak) UIButton *rightButton;          // 下一个
@property (nonatomic, assign) NSInteger showIndex;          // 显示的位置


@end

@implementation ViewController
{
    int _arrayCount;
}


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _arrayCount = 20;
    
    UIImageView *mBackImageView = [[UIImageView alloc] initWithFrame:self.view.frame];
    mBackImageView.image = [UIImage imageNamed:@"guide_back_default"];
    [self.view addSubview:mBackImageView];
    
    
    [self createSectorViewUI];
    
    [self createShowView];
    
    [self initData];
}


#pragma mark 加载数据
- (void)initData
{
    NSMutableArray *tArrays = [NSMutableArray array];
    
    for (int i = 0; i < _arrayCount; i++) {
        
        UIButton *btn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 60, 60)];
        [btn makeRound];
        btn.backgroundColor = [UIColor yellowColor];
        [btn setTitle:[NSString stringWithFormat:@"%i", i] forState:(UIControlStateNormal)];
        [tArrays addObject:btn];
    }
    
    if (self.sectorView) {
        
        [self.sectorView addSubViewWithSubViewArray:tArrays];
    }
}

#pragma mark 创建下边扇形界面
- (void)createSectorViewUI
{
    CGFloat H = XH_WIDTH / 2;
    XHSectorView *sectorView = [[XHSectorView alloc] initWithFrame:CGRectMake(0, XH_HEIGHT - H, XH_WIDTH, H)];
    [sectorView setAbroadViewRadius:550 andSpacing:130 showViewCount:5];
    sectorView.delegate = self;
    [self.view addSubview:sectorView];
    self.sectorView = sectorView;
}

#pragma mark 创建大图展示信息
- (void)createShowView
{
    UIView *backView = [[UIView alloc] initWithFrame:CGRectMake(0, 64 + 15, XH_WIDTH / 2., 200)];
    backView.height = self.sectorView.y - backView.y;
    backView.centerX = XH_WIDTH / 2.;
    backView.backgroundColor = [UIColor clearColor];
    backView.userInteractionEnabled = YES;
    [self.view addSubview:backView];
    self.backView = backView;
    
    UILabel *contentLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, backView.width, backView.height)];
    contentLabel.backgroundColor = [UIColor yellowColor];
    contentLabel.textColor = [UIColor redColor];
    contentLabel.textAlignment = NSTextAlignmentCenter;
    contentLabel.font = [UIFont systemFontOfSize:20];
    [backView addSubview:contentLabel];
    self.contentLabel = contentLabel;
    
    UIButton *leftButton = [[UIButton alloc] initWithFrame:CGRectMake(20, XH_HEIGHT / 2. - 40, 30, 50)];
    [leftButton setImage:[UIImage imageNamed:@"guide_home_left"] forState:(UIControlStateNormal)];
    [leftButton setImage:[UIImage imageNamed:@"guide_home_left_select"] forState:(UIControlStateSelected)];
    leftButton.centerY = backView.centerY;
    leftButton.tag = 10;
    [leftButton addTarget:self action:@selector(fanYeButtonClicked:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:leftButton];
    self.leftButton = leftButton;
    
    UIButton *rightButton = [[UIButton alloc] initWithFrame:CGRectMake(XH_WIDTH - leftButton.width - leftButton.x, leftButton.y, leftButton.width, leftButton.height)];
    [rightButton setImage:[UIImage imageNamed:@"guide_home_right"] forState:(UIControlStateNormal)];
    [rightButton setImage:[UIImage imageNamed:@"guide_home_right_select"] forState:(UIControlStateSelected)];
    rightButton.tag = 11;
    [rightButton addTarget:self action:@selector(fanYeButtonClicked:) forControlEvents:(UIControlEventTouchUpInside)];
    [self.view addSubview:rightButton];
    self.rightButton = rightButton;
}



#pragma mark 左右翻页按钮事件
- (void)fanYeButtonClicked:(UIButton *)btn
{
    if (btn.tag == 10) {    // 上一个
        
        if (self.showIndex > 0) {
            
            [self.sectorView nextToLeft];
        }
        
    } else if (btn.tag == 11) {     // 下一个
        
        if (self.showIndex < _arrayCount - 1) {
            
            [self.sectorView nextToRigth];
        }
    }
}


#pragma mark ---- XHSectorViewDelegate代理
- (void)slideEndWithIndex:(NSInteger)index
{
    NSLog(@"指向的子视图位置 %ld", index);
    
    // 翻书动画
    if (self.showIndex > index) {
        
        [self transitionWithType:@"pageUnCurl" WithSubtype:kCATransitionFromRight ForView:self.contentLabel];
        
    } else if (self.showIndex < index) {
        
        [self transitionWithType:@"pageCurl" WithSubtype:kCATransitionFromRight ForView:self.contentLabel];
    }
    
    
    self.showIndex = index;
    
    self.contentLabel.text = [NSString stringWithFormat:@"第 %ld 个", index];
    
    if (!self.showIndex) {
        
        self.leftButton.selected = YES;
        
    } else {
        
        self.leftButton.selected = NO;
    }
    
    if (self.showIndex == _arrayCount - 1) {
        
        self.rightButton.selected = YES;
        
    } else {
        
        self.rightButton.selected = NO;
    }
}

#pragma CATransition动画实现
- (void)transitionWithType:(NSString *)type WithSubtype:(NSString *)subtype ForView:(UIView *)view
{
    //创建CATransition对象
    CATransition *animation = [CATransition animation];
    
    //设置运动时间
    animation.duration = 0.7;
    
    //设置运动type
    animation.type = type;
    if (subtype != nil) {
        
        //设置子类
        animation.subtype = subtype;
    }
    
    //设置运动速度
    animation.timingFunction = UIViewAnimationOptionCurveEaseInOut;
    
    [view.layer addAnimation:animation forKey:@"animation"];
}




@end
