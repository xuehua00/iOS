//
//  XHSectorView.m
//  扇形滑动
//
//  Created by 逸族 on 2017/5/10.
//  Copyright © 2017年 yizu. All rights reserved.
//

#import "XHSectorView.h"
#import "UIView+YZ.h"

@interface XHSectorView ()

// 外圆
@property (nonatomic, weak) UIView *abroadView;
// 内圆
@property (nonatomic, weak) UIView *insideView;
// 内圆外圆距离
@property (nonatomic, assign) CGFloat spacing;  // 间距
// 移动的位置
@property (nonatomic, assign) CGFloat moveNum;
// 移动值
@property (nonatomic, assign) CGFloat moveX;
// 移动结束
@property (nonatomic, assign, getter=isEndMove) BOOL endMove;
// 外圆半径
@property (nonatomic, assign) CGFloat radius;
// subViewBegX(子视图在屏幕的起始点,x值最小的时候)
@property (nonatomic, assign) CGFloat subViewBegX;
// 子视图数组
@property (nonatomic, strong) NSMutableArray *subViewArrays;
// 滑动手势
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
// 界面中保持子视图的个数
@property (nonatomic, assign) NSInteger showViewCount;
// 每显示一个子视图所占的背景宽度
@property (nonatomic, assign) CGFloat showViewWidth;
// 第一触碰点
@property (nonatomic, assign) CGPoint beginPoint;
// 第二触碰点
@property (nonatomic, assign) CGPoint movePoint;


// 子视图的宽度
@property (nonatomic, assign) CGFloat subViewW;
// 第一个子视图的位置
@property (nonatomic, assign) CGFloat subFirstViewX;

// 记录居中子视图在数组中的位置
@property (nonatomic, assign) NSInteger moveIndex;


@end



@implementation XHSectorView


- (NSMutableArray *)subViewArrays
{
    if (!_subViewArrays) {
        _subViewArrays = [NSMutableArray array];
    }
    return _subViewArrays;
}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        UIView *abroadView = [[UIView alloc] init];
        abroadView.backgroundColor = [UIColor clearColor];
        abroadView.userInteractionEnabled = YES;
        [self addSubview:abroadView];
        self.abroadView = abroadView;
        
        // 加转动手势
        UIPanGestureRecognizer *panGesture =[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(slidePanGesture:)];
        self.panGesture = panGesture;
        [self.abroadView addGestureRecognizer:panGesture];
        
        UIView *insideView = [[UIView alloc] init];
        insideView.backgroundColor = [UIColor clearColor];
        [self addSubview:insideView];
        self.insideView = insideView;
    }
    return self;
}

/**
 设置外圆大小，环形间距，子视图的个数，子视图显示的数量
 
 @param radius 外圆半径
 @param spacing 环形间距
 @param showCount 子视图显示的个数
 */
- (void)setAbroadViewRadius:(CGFloat)radius andSpacing:(CGFloat)spacing showViewCount:(NSInteger)showCount
{
    self.radius = radius;
    self.spacing = spacing;
    self.showViewCount = showCount;
    self.showViewWidth = XH_WIDTH / self.showViewCount;
    self.subViewBegX = self.radius - XH_WIDTH / 2.;
    
    self.abroadView.frame = CGRectMake(0, 0, radius * 2, radius * 2);
    self.abroadView.centerX = self.centerX;
    [self.abroadView makeRound];
    
    self.insideView.frame = CGRectMake(spacing, spacing, (radius - spacing) * 2, (radius - spacing) * 2);
    self.insideView.centerX = self.abroadView.centerX;
    [self.insideView makeRound];
}


/**
 增加数据(子视图View)
 
 @param viewArray 增加子视图数组
 */
- (void)addSubViewWithSubViewArray:(NSArray *)viewArray
{
    for (int i = 0; i < viewArray.count; i++) {
        
        UIButton *btn = viewArray[i];
        btn.tag = i + self.subViewArrays.count;
        [btn addTarget:self action:@selector(selectButtonClicked:) forControlEvents:(UIControlEventTouchUpInside)];
        [self.abroadView addSubview:btn];
    }
    
    [self.subViewArrays addObjectsFromArray:viewArray];
    
    if (self.subViewArrays.count <= viewArray.count) {
        
        UIButton *tBtn = [viewArray firstObject];
        self.subViewW = tBtn.width;
        self.subFirstViewX = XH_WIDTH / 2. - self.subViewW / 2. - (XH_WIDTH - self.subViewW * self.showViewCount) / (self.showViewCount + 1) / 2.;
        self.moveNum = self.subFirstViewX;
        
        [self layoutViewFrame];
        
        if (self.subViewArrays.count) {
            
            self.moveIndex = 0;
        }
    }
}
// 点击按钮，然后按钮居中事件
- (void)selectButtonClicked:(UIButton *)btn
{
    NSInteger tInd = btn.tag - self.moveIndex;
    
    if (!tInd) {
        
        return;
    }
    
    self.moveNum -= self.showViewWidth * tInd;
    self.moveIndex = btn.tag;
    
    [self layoutViewFrame];
}

// 滑动手势
- (void)slidePanGesture:(UIPanGestureRecognizer *)pan
{
    if (!self.subViewArrays.count) {
        
        return;
    }
    
    if(pan.state == UIGestureRecognizerStateBegan){// 开始
        
        self.endMove = NO;
        
        self.beginPoint = [pan locationInView:self.abroadView];
        
    } else if (pan.state == UIGestureRecognizerStateChanged){// 移动中
        
        // sqrtf 开平方    fabs 绝对值
        self.movePoint = [pan locationInView:self.abroadView];
        
        self.moveX = sqrt(fabs(self.movePoint.x - self.beginPoint.x) * fabs(self.movePoint.x - self.beginPoint.x) + fabs(self.movePoint.y - self.beginPoint.y) * fabs(self.movePoint.y - self.beginPoint.y));
        
        if (self.movePoint.x > self.beginPoint.x) {
            
            self.moveNum += self.moveX;
            
        } else{
            
            self.moveNum -= self.moveX;
        }
        
        NSLog(@"移动后的位置 moveNum  %f", self.moveNum);
        
        // 最少值
        if (self.moveNum > self.subFirstViewX && self.moveNum > 0) {     // 子视图的起始位置
            
            self.moveNum = self.subFirstViewX;
        }
        
        // 可移动的最大值
        CGFloat maxX = -self.showViewWidth * self.subViewArrays.count + XH_WIDTH - self.subFirstViewX - self.subViewW / 2.;
        if (self.moveNum < maxX) {
            
            self.moveNum = maxX;
        }
        
        [self layoutViewFrame];
        
        self.beginPoint = self.movePoint;
        
        NSLog(@"移动到的点 %f", self.moveNum);
        
    } else if (pan.state == UIGestureRecognizerStateEnded){// 结束
        
        self.endMove = YES;
        
        NSLog(@"移动的位置   %f   每个子视图的宽度 %f",self.moveNum, self.showViewWidth);
        
        for (int i = 0; i < self.subViewArrays.count; i++) {
            
            if (self.moveNum > -self.showViewWidth - self.showViewWidth * i + self.subFirstViewX){
                
                self.moveNum = -self.showViewWidth * i + self.subFirstViewX;
                
                NSLog(@"第几个视图 %i", i);
                
                self.moveIndex = i;
                
                break;
            }
        }
        [self layoutViewFrame];
    }
}

- (void)layoutViewFrame
{
    NSLog(@"扇形开始布局位置");
    
    CGFloat radius = self.radius;
    CGFloat spacing = self.spacing;
    
    //  中心点
    CGFloat cX = 0.0;           // 中心X
    CGFloat cY = 0.0;           // 中心Y
    CGFloat margin = 0.0;
    
    for (int i = 0; i < self.subViewArrays.count; i++) {
        
        margin = i * self.showViewWidth;
        
        cX = fabs(self.subViewBegX) + self.showViewWidth / 2. + margin + self.moveNum ;
        cY = radius - sqrt((radius - spacing / 2) * (radius - spacing / 2) - (cX - radius) * (cX - radius));
        
        if (cX >= spacing / 2. && cX <= radius * 2 - spacing / 2.) {
            
            UIButton *btn = [self.subViewArrays objectAtIndex:i];
            
            if (self.isEndMove) {
                
                [UIView animateWithDuration:0.3 animations:^{
                    
                    btn.center = CGPointMake(cX , cY);
                }];
                
            } else {
                
                btn.center = CGPointMake(cX , cY);
            }
        }
    }
}

/**
 下一个
 */
- (void)nextToRigth
{
    self.moveNum -= self.showViewWidth;
    self.moveIndex += 1;
    
    //    self.endMove = YES;
    
    [self layoutViewFrame];
}


/**
 上一个
 */
- (void)nextToLeft
{
    self.moveNum += self.showViewWidth;
    self.moveIndex -= 1;
    
    //    self.endMove = YES;
    
    [self layoutViewFrame];
}

#pragma mark 记录当前居中视图，重写set方法，将值传给控制器
- (void)setMoveIndex:(NSInteger)moveIndex
{
    _moveIndex = moveIndex;
    
    if ([self.delegate respondsToSelector:@selector(slideEndWithIndex:)]) {
        
        [self.delegate slideEndWithIndex:moveIndex];
    }
}

/**
 清除AbroadView所有子控件
 */
- (void)clearAllAbroadViewSub
{
    for (UIView *tView in self.abroadView.subviews) {
        
        [tView removeFromSuperview];
    }
    
    [self.subViewArrays removeAllObjects];
}









@end
